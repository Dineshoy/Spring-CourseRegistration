package com.cg.cra.service;

import java.util.List;

import com.cg.cra.entity.Course;
import com.cg.cra.entity.Registration;

public interface RegistrationService {
	
	long register(Registration reg);
	List <Course> getAllCourses();
	

}
