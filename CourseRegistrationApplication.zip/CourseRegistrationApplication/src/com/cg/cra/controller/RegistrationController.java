package com.cg.cra.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.cra.entity.Course;
import com.cg.cra.entity.Registration;
import com.cg.cra.service.RegistrationService;

@Controller
public class RegistrationController {
	@Autowired
	RegistrationService rser;
	
	@RequestMapping(value="home")
	public String goHome(Model model){
		
		List<Course> clist= rser.getAllCourses();
		model.addAttribute("clist", clist);
		model.addAttribute("reg", new Registration());
		return "Register";
	}
	
	@RequestMapping(value="register")
	public String register(@ModelAttribute("reg") @Valid Registration reg, BindingResult res, Model model){
		if(res.hasErrors())
		{
			List<Course> clist =rser.getAllCourses();
			model.addAttribute("clist", clist);
			model.addAttribute("reg", reg);
			return "Register";
		}else {
			long regid = rser.register(reg);
			model.addAttribute("regid", regid);
			return "Success";
		}
	}
	
	

}
