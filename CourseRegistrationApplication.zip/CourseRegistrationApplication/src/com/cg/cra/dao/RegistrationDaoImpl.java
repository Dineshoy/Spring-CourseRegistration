package com.cg.cra.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.cra.entity.Course;
import com.cg.cra.entity.Registration;


@Repository
public class RegistrationDaoImpl implements RegistrationDao {

	@PersistenceContext
	EntityManager em;
	
	@Override
	public long insertRegistration(Registration reg) {
	
		em.persist(reg);
		return reg.getRegId();
	}

	@Override
	public List<Course> getAllCourses() {
		
		String jpql="SELECT course FROM Course course";
		TypedQuery<Course> query=em.createQuery(jpql, Course.class);
		return query.getResultList();
	}

}
